#!/bin/bash

V="$PWD"
NAUTILUS_SCRIPT="$HOME/.gnome2/nautilus-scripts"


[ -d "$NAUTILUS_SCRIPT" ] || mkdir -p "$NAUTILUS_SCRIPT" 


LANG=$(zenity  --list  --text "Select language" --radiolist  --column "" --column "language" TRUE en FALSE es);
[ -z $LANG ] && exit 0

gksu cp $V/locale/$LANG/LC_MESSAGES/xml-background-creator.mo /usr/share/locale/$LANG/LC_MESSAGES

FLAG=1
while [ $FLAG -eq 1 ]; do

	#name of the nautilus dialog
	DIALOG=$(zenity --entry --entry-text "create xml background" --text "Input the name of the nautilus dialog for the script")
	[ $? -ne 0 ] && echo "aborting ..." && exit 0
	echo "Nautilus dialog for the script set to $DIALOG ..."
	FLAG=0

	# If you dont put a name to the file	
	if [ -z $DIALOG ]; then
		echo "Not valid filename found. Then, again ..."
		zenity --info --text "You must put a name to the nautilus dialog!"
		FLAG=1
	fi

done


cp xmlback "$NAUTILUS_SCRIPT"
mv "$NAUTILUS_SCRIPT"/xmlback "$NAUTILUS_SCRIPT"/"$DIALOG"

echo "The xml-background-creator script has been installed"
zenity --info --timeout 5 --text "Script installed"
